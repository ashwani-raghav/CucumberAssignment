package Day1;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SeleniumLaunch {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\IN002G9X\\Desktop\\Eclipse\\Demo\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
//		driver.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-checkbox/");
////		String s=driver.getTitle();
//		driver.manage().window().maximize();
//		driver.navigate().to("https://in.search.yahoo.com/?fr2=inr");
//		Thread.sleep(1000);
//		driver.navigate().refresh();
//		Thread.sleep(1000);
//		driver.navigate().back();
//		Thread.sleep(1000);
//		driver.navigate().forward();
//		Thread.sleep(1000);
//		driver.findElement(By.name("q")).sendKeys("Ashwani" + Keys.ENTER);
//		List<WebElement> webelements=driver.findElements(By.xpath("//a//h3"));
//		for(WebElement element:webelements)
//		{
//			System.out.println(element.getText());
//		}
//		System.out.println(s);
//		driver.findElement(By.xpath("//div[@class='ui-checkbox']/label[text()='Two']")).click();
//		driver.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/");
//		driver.findElement(By.xpath("//div[@class='ui-radio']/label[text()='Two']")).click();

//		driver.get("https://www.techlistic.com/p/demo-selenium-practice.html");
//		driver.manage().window().maximize();
//		Thread.sleep(5000);
//		List<WebElement> weColData=driver.findElements(By.xpath("//table[@id='customers']//tr//td"));
//		for(int i=0;i<weColData.size();i++) {
//			
//			if(i%3==1)
//			System.out.println(weColData.get(i).getText());
//		}
//		Thread.sleep(5000);
		// Navigating to google
//		driver.findElement(By.xpath("//div[@class='ui-panel-dismiss']")).sendKeys(Keys.CONTROL + "T");
////		((JavascriptExecutor)driver).executeScript("window.open()");
//		Set<String> tabs=driver.getWindowHandles();
//		for(String eachTab:tabs) {
//			System.out.println(eachTab);
//			driver.switchTo().window(eachTab);
//		}
//		driver.get("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
//		Thread.sleep(5000);
//		driver.switchTo().frame("globalSqa");
//		driver.findElement(By.partialLinkText("Home")).click();
//		Thread.sleep(5000);
//		driver.close();
		driver.get("https://www.google.com/");
		Thread.sleep(2000);
		WebElement inputSerachBox = driver.findElement(By.name("q"));
		Actions action=new  Actions(driver);
		action.keyDown(inputSerachBox,Keys.SHIFT);
		action.sendKeys(inputSerachBox,"SELenium");
		action.keyUp(inputSerachBox,Keys.SHIFT);
		action.build().perform();
		action.doubleClick().build().perform();
//		inputSerachBox.sendKeys(inputSerachBox,Keys.CONTROL+"C");
        //Double click
        //CTRL+C
        
		Thread.sleep(2000);
		driver.close();
		
	}

}
