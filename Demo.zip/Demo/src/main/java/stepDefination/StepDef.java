package stepDefination;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDef {
	public WebDriver driver;

	@Given("I want to launch Google.com")
	public void i_want_to_launch_google_com() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\IN002G9X\\Desktop\\Eclipse\\Demo\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("https://www.google.com/");
	    Thread.sleep(1000);
	}

	@When("I enter text {string} in google search box")
	public void i_enter_text_in_google_search_box(String string) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("q")).sendKeys(string + Keys.ENTER);
		Thread.sleep(1000);
	}

	@Then("I click on first link")
	public void i_click_on_first_link() {
	    // Write code here that turns the phrase above into concrete actions
		List<WebElement> webelements=driver.findElements(By.xpath("//a//h3"));
		for(WebElement element:webelements)
			{
				element.click();
				break;
			}
	    driver.close();
	}


}
